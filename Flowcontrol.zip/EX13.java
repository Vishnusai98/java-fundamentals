import java.lang.*;
import java.io.*;
class EX13
{
	public static void main(String[] args)throws Exception 
	{
	int count=0;
	for (int i=10;i<99;i++ )
	{
	 if(i%2==0)
	 {
	 	count=count+1;
	 }
	 else
	 	System.out.print(i+"\t");
	}
}
}