import java.lang.*;
import java.io.*;
class Ex1a
{
	public static void main(String[] args)throws Exception {
		System.out.println("enter your number");
		DataInputStream dis=new DataInputStream(System.in);
		int n=Integer.parseInt(dis.readLine());
		if(n>0)
			System.out.println(n+"is a postive Number");
		else if (n<0) 
			System.out.println(n+"is a nagative Number");
		else
			System.out.println("given Number is zero");
}
}