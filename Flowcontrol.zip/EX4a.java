import java.lang.*;
import java.io.*;
class EX4a
{
	public static void main(String[] args)throws Exception {
		char first='s';
		char second='e';
		if(first>second)
			System.out.println(second+","+first);
		else
			System.out.println(first+","+second);
		
	}
}