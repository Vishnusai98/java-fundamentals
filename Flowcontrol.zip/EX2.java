import java.lang.*;
import java.io.*;
class EX2
{
	public static void main(String[] args)throws Exception 
	{
	System.out.println("enter your number");
	DataInputStream obj=new DataInputStream(System.in);
	int n=Integer.parseInt(obj.readLine());
	if(n%2==0)
	System.out.println("given number is even:"+" "+n);
	else 
	System.out.println("given number is odd:"+" "+n);
	}
}