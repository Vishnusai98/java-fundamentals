import java.lang.*;
import java.io.*;
import java.util.*;
class EX8
{
	public static void main(String[] args)throws Exception {
		System.out.println("enter your Character \n R, B,G,O,Y,W");
		Scanner obj=new Scanner(System.in);
		char ch= obj.next().charAt(0);
		switch(ch)
		{
			case 'R':System.out.println("red"); break;
			case 'B':System.out.println("blue"); break;
			case 'G':System.out.println("green"); break;
			case 'O':System.out.println("orange"); break;
			case 'Y':System.out.println("Yellow"); break;
			case 'W':System.out.println("white"); break;
			default :System.out.println("wrong input");
		}
}
}