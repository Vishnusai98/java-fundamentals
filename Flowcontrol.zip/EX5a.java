class EX5a
{
    public static void main (String[] args)throws Exception
    {
        char read='@'; 
               if((read>96&&read<123)||(read>64&&read<91))
            System.out.println("Alphabet");
        else if(read>47&&read<58)
            System.out.println("Digit");
        else
            System.out.println("Special Character");
    }
    }