import java.lang.*;
import java.io.*;
class EX1b
{
	public static void main(String[] args)throws Exception {
		System.out.println("enter your first value");
		DataInputStream obj=new DataInputStream(System.in);
		int a=Integer.parseInt(obj.readLine());
		System.out.println("enter your second value");
		int b=Integer.parseInt(obj.readLine());
		int compare1=a%10;
        int compare2=b%10;
       if (compare1==compare2)
           System.out.println("true");
        else 
        	System.out.println("false");
		
	}
}
   
