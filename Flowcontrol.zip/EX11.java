import java.lang.*;
import java.io.*;
class EX11
{
	public static void main(String[] args) throws Exception
	{
	for (int i=23;i<57;i++ )
				if(i%2==0)
				System.out.println(i);	
	}
}