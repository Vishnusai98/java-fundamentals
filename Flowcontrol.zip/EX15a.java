import java.lang.*;
import java.io.*;
class  EX15a
{
	public static void main(String[] args)throws Exception {
		System.out.println("enter your number");
		DataInputStream dis=new DataInputStream(System.in);
		int n=Integer.parseInt(dis.readLine());
		for (int i=0;i<=n-1;i++ )
		 {
			for (int j=0;j<=i;j++ ) 
			{
				System.out.print("*");
			}
			System.out.println();
		}
		}
		
	}