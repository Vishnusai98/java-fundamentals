import java.io.*;
import java.lang.*;
class EX15b
{
	public static void main(String[] args)throws Exception
	 {
		System.out.println("enter your number");
		DataInputStream obj=new DataInputStream(System.in);
		int n=Integer.parseInt(obj.readLine());
		for (int i=0;i<=n-1;i++ ) 
		{
		for (int j=n;j>=i;j--)
		 {
		System.out.print("*");		
			}
			System.out.println();	
		}

	}
}