import java.lang.*;
import java.io.*;
class EX7a
{
	public static void main(String[] args)throws Exception
	 {
	char value='a';
	if(value=='a')
	System.out.println("a->A");	
	}
}