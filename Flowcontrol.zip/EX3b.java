import java.lang.*;
import java.io.*;
class EX3b
{
	public static void main(String[] args)throws Exception {
		
		for (int i=0;i<args.length;i++ ) {
			System.out.print(args[i]+" ");
			
		}
		
	}
}