import java.lang.*;
import java.io.*;
class EX4b
{
	public static void main(String[] args)throws Exception {
		char first='a';
		char second='e';
		System.out.println(first+","+second);
	}
}