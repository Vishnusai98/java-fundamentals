import java.lang.*;
import java.io.*;
class SOD
{
	public static void main(String[] args)throws Exception 
	{
	System.out.println("enter your digits");
	DataInputStream dis=new DataInputStream(System.in);
	int n=Integer.parseInt(dis.readLine());
int sum=0;
while(n>0)
{
	int r=n%10;
	sum=sum+r;
n=n/10;
	}
	System.out.println("Sum of digits is:-"+ " "+sum);
}
}