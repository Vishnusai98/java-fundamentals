import java.lang.*;
import java.io.*;
class EX7b
{
	public static void main(String[] args)throws Exception {
		char  value='A';
		if(value=='A')
			System.out.println("A->a");		
	}
}