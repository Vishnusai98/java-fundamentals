import java.lang.*;
import java.io.*;
class EX10
{
	public static void main(String[] args)throws Exception
	 {
	for (int i=1;i<=10;i++ ) 
			
	System.out.print(i+"\t");
	}
}