import java.lang.*;
import java.io.*;
class EX3a
{
	public static void main(String[] args)throws Exception {
		int store=args.length;
		if(store==0)
			System.out.println("no value");
		else
		{
			System.out.print(args[0]);
			for (int i=1;i<=store;i++ ) {
				System.out.print(" "+args[i]);
							}
		}
		
	}
}