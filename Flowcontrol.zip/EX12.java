import java.lang.*;
import java.io.*;
class EX12
{
	public static void main(String[] args)throws Exception 
	{
		System.out.println("enter your number:");
		DataInputStream dis=new DataInputStream(System.in);
		int n=Integer.parseInt(dis.readLine());
		int count=0;
		for (int i=2;i<=n-1;i++ ) {
			if(n%2==0)
		{
			count=count+1;
		}}
if(count==0)
	System.out.println("given number is prime:-"+" "+n);
else
	System.out.println("given number is not a prime:-"+" "+n);
		
	}
}
