import java.lang.*;
import java.io.*;
class EX17
{
	public static void main(String[] args)throws Exception
	 {
	System.out.println("enter your value");	
	DataInputStream obj=new DataInputStream(System.in);
	int n=Integer.parseInt(obj.readLine());
	int s=0;
	int temp=n;
	while (n>0)
	 {
		int r=n%10;
		s=s*10+r;
		n=n/10;
}
if(temp==s)
System.out.println("given number is palandrome");
else
System.out.println("given number is not a palandrome");
}
	}
