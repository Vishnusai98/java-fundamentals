import java.io.*;
import java.util.*;
class Box
{
	float h,w,d;
	Box(float width,float height,float depth)
	{
		w=width;
		h=height;
		d=depth;
	}
	double volume()
	{
		double v;
		v=h*w*d;
		return v;
	}
	public static void main(String[] args) {
		Box obj=new Box(10.5f,12.5f,10.f);
		System.out.println(obj.volume());
	}
}