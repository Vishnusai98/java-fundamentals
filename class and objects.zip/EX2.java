import java.io.*;
import java.lang.Math;
class EX2
{
	public static void main(String[] args) {
		System.out.println(Calculator.powerInt(2,5));
		System.out.println(Calculator.powerDouble(85.5d,2.5d));
	}
}
 class Calculator
{
	static double powerInt(int num1,int num2)
	{
		return Math.pow(num1,num2);
	}
	static double powerDouble(double num1,double num2)
	{
		return Math.pow(num1,num2);
	}
}
