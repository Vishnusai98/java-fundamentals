public class Orange extends Fruit {
public void eat() {
System.out.println("it tastes like an orange");
}
}