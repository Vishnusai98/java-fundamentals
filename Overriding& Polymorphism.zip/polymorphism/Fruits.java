public class Fruits 
{
public static void main(String args[])
{
Fruit ab = new Fruit();
ab.eat();
Apple abc = new Apple();
abc.eat();
Orange abcd = new Orange();
abcd.eat();
}
}
