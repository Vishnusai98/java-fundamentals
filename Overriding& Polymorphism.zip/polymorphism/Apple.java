public class Apple extends Fruit {
public void eat() {
System.out.println("It tastes like an apple");
}
}