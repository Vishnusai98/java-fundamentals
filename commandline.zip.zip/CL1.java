import java.lang.*;
import java.io.*;
class CL1
{
	public static void main(String[] a)throws Exception {
		System.out.println(a[0]+" "+" technologies"+" "+a[1]);
		
	}
}