import java.lang.*;
import java.io.*;
class CLW
{
	public static void main(String[] a)throws Exception 
	{
	System.out.println("welcome!"+" "+a[0]);
	}
}