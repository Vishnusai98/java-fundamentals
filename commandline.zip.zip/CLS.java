import java.lang.*;
import java.io.*;
class CLS
{
	public static void main(String[] a)throws Exception 
	{
	int x=Integer.parseInt(a[0]);
	int y=Integer.parseInt(a[1]);
	int z=x+y;
	System.out.println("sum of numbers"+x+"and"+y+"is "+z);
	}
}