import java.lang.*;
import java.io.*;
class CL2
{
	public static void main(String[] a)throws Exception {
		System.out.println(a[0]+" "+"Technologies");
		System.out.println(a[1]);
	}
}