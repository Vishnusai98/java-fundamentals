import java.io.*;
import java.lang.*;
import java.util.*;
class E9
{public static void main(String[] args) {
        int a[]={1,10,3,10,9,4,10};
        for (int i=0;i<a.length;i++ ) {
            if(a[i]==10)
            {
                a[i]=0;
            }           
        }
        for (int i=0;i<a.length ;i++ ) 
            System.out.print(a[i]+" ");
        }
}
