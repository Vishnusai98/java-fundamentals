import java.util.Arrays; 
 class E12
  {
void middleWay(int a[],int b[])
{
	int c[]=new int[2];
	c[0]=a[1];
	c[1]=b[1];
	for (int i=0;i<2 ;i++ ) {
		System.out.print("["+c[i]+"]");
		
	}
}

public static void main(String[] args)
 {
    int[] a = {1, 2, 3};
	int[] b = {4, 5, 6};
	E12 obj=new E12();
	obj.middleWay(a , b); 	 
 }
}
