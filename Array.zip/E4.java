import java.lang.*;
import java.io.*;
import java.util.*;
class E4
{
	public static void main(String[] args)throws Exception
	 {
	int[] array={65,69,67,75};
	 int length = array.length;
	 char[] array1=new char[length];
   for (int i=0;i<length;i++) {

        array1[i] = (char) array[i];
    
    System.out.println(array1[i]);
}
}
}