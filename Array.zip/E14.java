import java.lang.*;
import java.io.*;
class E14
{
	public static void main(String[] args)throws Exception
	 { System.out.println("given array elements is");
	 	int a[][]=new int[3][3];
	 	for (int i=0;i<3;i++ ) 
	 	{
	 	for (int j=0;j<3;j++ )
	 	 {
	 	a[i][j]=Integer.parseInt(args[3*i+j]);		
	 		}	
	 	}
	for (int i=0;i<3;i++ ) {
		for(int j=0;j<3;j++)
		{
			System.out.print(a[i][j]+" ");
		}
		System.out.println();
	}
		int max=a[0][0];
		for (int i=0;i<3;i++ )
		 {
		for (int j=0;j<3;j++ ) 
		{
		if(max<a[i][j])
		{
			max=a[i][j];
		}		
			}	
		}
System.out.println("the biggest element in the given array is"+max);
		}
			
		}	
		


