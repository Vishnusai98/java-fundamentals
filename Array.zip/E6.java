import java.lang.*;
import java.io.*;
class E6
{
	public static void main(String[] args)throws Exception
	 {
	System.out.println("enter size of array");
	DataInputStream obj=new DataInputStream(System.in);
	int n=Integer.parseInt(obj.readLine());
	int a[]=new int[n];
	System.out.println("enter elements in array");
	for (int i=0;i<n;i++ )
	 {
	a[i]=Integer.parseInt(obj.readLine());	
	}
System.out.println("array elements are:");
	for (int i=0;i<n;i++) 
	{
			System.out.println(a[i]);
		}	
		for (int i=0;i<n-1;i++)
		 {
		for(int j=0;j<n-1;j++)
		{
			if (a[j]>a[j+1])
	 {
			int temp=a[j];
			a[j]=a[j+1];
			a[j+1]=temp;	
			}
		}	
		}
		for (int i=0;i<=n-1;i++) 
			{
				System.out.print(a[i]"\t");
			}
	}
}