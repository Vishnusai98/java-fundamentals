import java.lang.*;
import java.io.*;
class E1
{
	public static void main(String[] args)throws Exception 
	{
		int sum=0;
	System.out.println("enter size of an array");
	DataInputStream obj=new DataInputStream(System.in);
	int n=Integer.parseInt(obj.readLine());
	int a[]=new int[n];
	System.out.println("enter elements in array");
	for(int i=0;i<=n-1;i++)
	{
		a[i]=Integer.parseInt(obj.readLine());
	}
	for (int i=0;i<=n-1;i++ )
	 {
	System.out.println("array elements are"+a[i]);	
		}	
		for (int i=0;i<=n-1;i++ )
		 {
		sum=sum+a[i];
	}
		System.out.println("Sum of array is"+sum);
	int avg=sum/n;
	System.out.println("average is"+avg);	
		
	}
}