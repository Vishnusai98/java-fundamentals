import java.io.*;
import java.lang.*;
class E10
{
	public static void main(String[] args) {
		int a[]={1,0,1,0,0,1,1};
		int left=0;
		int right=a.length-1;
		System.out.println("before arragement");
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]+" ");
		}
		while(left<right)
		{
			while(a[left]%2 == 0 && left < right)
				left++;
			while(a[right]%2 == 1 && left<right)
				right--;
			if (left<right) {
				int temp=a[left];
				a[left]=a[right];
				a[right]=temp;
				left++;
				right--;
			}
		}
System.out.println("\n After arragment  position");
for (int i=0;i<a.length;i++ ) {
	System.out.println(a[i]+" ");
}
		
	}
}
