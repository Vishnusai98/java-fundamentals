import java.lang.*;
import java.io.*;
class E3
{
	public static void main(String[] args)throws Exception
	 {
	int a[]={1,4,34,56,7};
	int s=90;
	int position=0;
	for (int i=0;i<a.length;i++ )
	 {
	 	if(a[i]==s)
	 	position=i;
	 }
	 if (position!=0)
	 	System.out.println(position);
	 	else
	 		System.out.println(-1); 
	 	
	 
}
}