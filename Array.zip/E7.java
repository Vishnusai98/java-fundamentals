import java.lang.*;
import java.io.*;
import java.util.*;
public class E7 {
 
    public static void removeDuplicateUsingSorting(int arr[]) {
 
        Arrays.sort(arr);
 
        int len = arr.length;
        int j = 0;
        for (int i = 0; i < len - 1; i++) {
            if (arr[i] != arr[i + 1]) {
                arr[j++] = arr[i];
            }
        }
 
        arr[j++] = arr[len - 1];
 
        for (int k = 0; k < j; k++) {
           System.out.print(arr[k] + " ");
        }
     }
 
     public static void main(String[] args) {
 
        int arr[] = { 12,34,12,45,65,89 };
        removeDuplicateUsingSorting(arr);
 
     }
 }