import java.io.*;
class E11
{
    public static void main(String[] args) {     
 int i;
 int [] x= {1,4,1,4};
   int one = 0;
   int four=1;
for(i =0; i < x.length; i++)
 { 
 if (x[i] == 1 || x[i] == 4) 
 one=1;
 else
 four=2;
  } 
  if (one==1 && four==1) 
  System.out.println("True");
  else
  System.out.println("False");



}}