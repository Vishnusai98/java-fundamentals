import java .io.*; 
import java.lang.*;
  import java.util.*;
class E8c
{ 
static void sumexcludingrange(int li[], int a, int b) 
{ 
    int sum = 0; 
    boolean add = true; 
    for (int i = 0;  
             i < li.length; i++) 
    {  
        if (li[i] != a &&  
             add == true) 
            sum = sum + li[i];  
        else if (li[i] == a) 
            add = false; 
        else if( li[i] == b) 
            add = true; 
    } 
    System.out.print(sum); 
} 
public static void main(String[] args) 
{ 
    int lis[] = {1,6,4,7,9}; 
    int a = 6; 
    int b = 7; 
      
    sumexcludingrange(lis, a, b); 
} 
}