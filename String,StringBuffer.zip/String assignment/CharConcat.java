import java.util.Scanner;
public class CharConcat {

	public static void main(String[] args) {
	Scanner ab = new Scanner(System.in);		
	System.out.println("enter two strings");
		String str1;
		String str2 ;
		str1=ab.nextLine();
		str2=ab.nextLine();

		
		str1 = str1.toLowerCase();
		str2 = str2.toLowerCase();
		
		StringBuffer sb = new StringBuffer();
		sb.append(str1);
		
		if (str1.charAt(str1.length() - 1) == str2.charAt(0)) {
			sb.append(str2.substring(1, str2.length()));
		} else {
			sb.append(str2);
		}
		
		System.out.println(sb);		
		
		sb.append(str1);
		
	}

}