
/*
 *  Write a Program that will check whether a given String is Palindrome or not
 * */

import java.util.Scanner;
class CharPal {
	
	public static void main(String[] args) {
		String input1;
		Scanner ab = new Scanner(System.in);
		System.out.println("enter a String");
		input1 = ab.nextLine();
		int digitCount = input1.length();
		int isPalindrome = 1;
		
		int range = digitCount / 2;
		if (digitCount % 2 == 0) 
		range--;
		
		for (int i = 0; i <= range; i++)
		{
		if (input1.charAt(i) != input1.charAt(digitCount - i - 1)) 
		isPalindrome = 0;
		}
		if(isPalindrome ==1)
		System.out.println(input1+" is a palindrome String");
		else
		System.out.println(input1+" is not a palindrome String");		
	}

}