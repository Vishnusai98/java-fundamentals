import java.util.Scanner;
public class WiWiWi {

	public static void main(String[] args) {
	Scanner console = new Scanner(System.in);
	System.out.println("enter a string");	
	String str;
	str = console.nextLine();
		int n = str.length();
		
		String repeater = "";
		
		if (n < 2) repeater = str;
		else repeater = str.substring(0, 2);
		
		String output = "";
		
		for (int i = 0; i < n; i++) {
			output += repeater;
		}
		
		System.out.println(output);

	}

}