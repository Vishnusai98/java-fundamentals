import java.util.Scanner;
public class CatDog {

	public static void main(String[] args) {
Scanner ab = new Scanner(System.in);
System.out.println("enter a String");
		String str ;
		str=ab.nextLine();
		String output;
		
		if (str.length() % 2 == 0) {
			output = str.substring(0, str.length() / 2);
		} else {
			output = null;
		}
		
		System.out.println(output);
	}

}