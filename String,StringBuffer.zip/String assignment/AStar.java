import java.util.Scanner;
public class AStar {

	public static void main(String[] args) {
System.out.println("enter a string inclusive of *");		
Scanner ab =new Scanner(System.in);
		String str =ab.nextLine();
		
		String[] strs = str.split(".[\\*]+.");
		
		StringBuffer sb = new StringBuffer();
		
		for (String x : strs)
			sb.append(x);
		
		System.out.println(sb);

	}

}
