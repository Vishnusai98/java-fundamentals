import java.util.Scanner;
public class FLast {
public static void main(String[] args) 
{
Scanner ab =new Scanner(System.in);
		System.out.println("enter a string");
		String str;
		str = ab.nextLine();
		
		str = str.substring(1, str.length() - 1);
		
		System.out.println(str);
	}

}