/**
 * The Student class, subclass of Person.
 */
public class Student extends Person {
   // private instance variable
   /** Constructs a Student instance with the given name and address */
   public Student(String name) {
      Super(name);
   }
   
  	
   
  
}